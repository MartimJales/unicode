void parse(char *line);
void PUSH(long val);
long POP();
void PRINT_STACK();
